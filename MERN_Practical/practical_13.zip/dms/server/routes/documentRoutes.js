const router = require("express").Router();
const ctrl = require("../controllers/documentController");
const { protect } = require("../middleware/auth");
const upload = require("../middleware/upload");

router.use(protect); // every document route requires a valid JWT

router.post("/", upload.single("file"), ctrl.upload);
router.get("/", ctrl.list);
router.get("/:id", ctrl.getOne);
router.get("/:id/download", ctrl.download);
router.delete("/:id", ctrl.remove);

module.exports = router;
