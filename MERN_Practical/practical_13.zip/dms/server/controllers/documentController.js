const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const Document = require("../models/Document");

const UPLOAD_DIR = path.join(__dirname, "..", "uploads");
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Find a document only if it belongs to the logged-in user
const findOwned = async (req) => {
  if (!mongoose.isValidObjectId(req.params.id)) return null;
  return Document.findOne({ _id: req.params.id, owner: req.user._id });
};

exports.upload = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });
    const doc = await Document.create({
      owner: req.user._id,
      title: (req.body.title || "").trim() || req.file.originalname,
      description: req.body.description || "",
      originalName: req.file.originalname,
      storedName: req.file.filename,
      mimeType: req.file.mimetype,
      size: req.file.size,
    });
    res.status(201).json(doc);
  } catch (err) {
    if (req.file) fs.unlink(req.file.path, () => {});
    next(err);
  }
};

// GET /api/documents?search=term
exports.list = async (req, res, next) => {
  try {
    const filter = { owner: req.user._id };
    const q = (req.query.search || "").trim();
    if (q) {
      const rx = new RegExp(escapeRegex(q), "i");
      filter.$or = [{ title: rx }, { description: rx }, { originalName: rx }];
    }
    const docs = await Document.find(filter).sort({ createdAt: -1 });
    res.json(docs);
  } catch (err) {
    next(err);
  }
};

exports.getOne = async (req, res, next) => {
  try {
    const doc = await findOwned(req);
    if (!doc) return res.status(404).json({ message: "Document not found" });
    res.json(doc);
  } catch (err) {
    next(err);
  }
};

exports.download = async (req, res, next) => {
  try {
    const doc = await findOwned(req);
    if (!doc) return res.status(404).json({ message: "Document not found" });
    const filePath = path.join(UPLOAD_DIR, doc.storedName);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File missing on server" });
    }
    res.download(filePath, doc.originalName);
  } catch (err) {
    next(err);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const doc = await findOwned(req);
    if (!doc) return res.status(404).json({ message: "Document not found" });
    fs.unlink(path.join(UPLOAD_DIR, doc.storedName), () => {});
    await doc.deleteOne();
    res.json({ message: "Document deleted" });
  } catch (err) {
    next(err);
  }
};
