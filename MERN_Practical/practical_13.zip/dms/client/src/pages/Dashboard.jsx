import { useCallback, useEffect, useRef, useState } from "react";
import api, { errMsg } from "../api";
import { useAuth } from "../context/AuthContext";

const formatSize = (bytes) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
};

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [docs, setDocs] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);

  const fetchDocs = useCallback(async (term) => {
    setLoading(true);
    try {
      const { data } = await api.get("/documents", { params: { search: term } });
      setDocs(data);
      setError("");
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setLoading(false);
    }
  }, []);

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => fetchDocs(search), 300);
    return () => clearTimeout(t);
  }, [search, fetchDocs]);

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return setError("Please choose a file");
    const fd = new FormData();
    fd.append("file", file);
    fd.append("title", title);
    fd.append("description", description);
    setUploading(true);
    setError("");
    try {
      await api.post("/documents", fd);
      setNotice("Document uploaded");
      setTitle("");
      setDescription("");
      setFile(null);
      if (fileRef.current) fileRef.current.value = "";
      fetchDocs(search);
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setUploading(false);
    }
  };

  const handleDownload = async (doc) => {
    try {
      const res = await api.get(`/documents/${doc._id}/download`, {
        responseType: "blob",
      });
      const url = URL.createObjectURL(res.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.originalName;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(errMsg(err));
    }
  };

  const handleDelete = async (doc) => {
    if (!window.confirm(`Delete "${doc.title}"? This cannot be undone.`)) return;
    try {
      await api.delete(`/documents/${doc._id}`);
      setNotice("Document deleted");
      setDocs((d) => d.filter((x) => x._id !== doc._id));
    } catch (err) {
      setError(errMsg(err));
    }
  };

  return (
    <div className="layout">
      <header className="topbar">
        <h2>DocuVault</h2>
        <div className="topbar-right">
          <span className="muted">Hi, {user?.name}</span>
          <button className="btn" onClick={logout}>
            Logout
          </button>
        </div>
      </header>

      <main className="content">
        {error && (
          <div className="alert" onClick={() => setError("")}>
            {error}
          </div>
        )}
        {notice && (
          <div className="success" onClick={() => setNotice("")}>
            {notice}
          </div>
        )}

        <section className="card">
          <h3>Upload a document</h3>
          <form className="upload-form" onSubmit={handleUpload}>
            <input
              placeholder="Title (optional)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <input
              placeholder="Description (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <input
              ref={fileRef}
              type="file"
              onChange={(e) => setFile(e.target.files[0] || null)}
            />
            <button className="btn primary" disabled={uploading}>
              {uploading ? "Uploading..." : "Upload"}
            </button>
          </form>
          <p className="muted small">
            Allowed: PDF, Word, Excel, PowerPoint, TXT, CSV, PNG, JPG (max 10 MB)
          </p>
        </section>

        <section className="card">
          <div className="list-head">
            <h3>My documents ({docs.length})</h3>
            <input
              className="search"
              type="search"
              placeholder="Search by title, description or file name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {loading ? (
            <p className="muted">Loading...</p>
          ) : docs.length === 0 ? (
            <p className="muted">
              {search ? "No documents match your search." : "No documents yet. Upload your first one above."}
            </p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>File</th>
                    <th>Size</th>
                    <th>Uploaded</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {docs.map((d) => (
                    <tr key={d._id}>
                      <td data-label="Title">
                        <strong>{d.title}</strong>
                        {d.description && <div className="muted small">{d.description}</div>}
                      </td>
                      <td data-label="File">{d.originalName}</td>
                      <td data-label="Size">{formatSize(d.size)}</td>
                      <td data-label="Uploaded">
                        {new Date(d.createdAt).toLocaleDateString()}
                      </td>
                      <td data-label="Actions" className="actions">
                        <button className="btn small-btn" onClick={() => handleDownload(d)}>
                          Download
                        </button>
                        <button className="btn danger small-btn" onClick={() => handleDelete(d)}>
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
