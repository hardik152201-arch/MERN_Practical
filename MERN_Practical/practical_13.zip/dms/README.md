# DocuVault - MERN Document Management System

Practical 13: Full-stack Document Management System using MongoDB, Express.js, React.js (Vite) and Node.js.

## Features
- User registration and login (bcrypt-hashed passwords, JWT authentication)
- Protected API routes and protected React routes
- Document upload with file type and size validation (Multer)
- List, search, download and delete documents
- Each user can access only their own documents (every query filters by `owner`)
- Responsive dashboard (table turns into cards on mobile)

## Project Structure
```
dms/
  server/
    server.js
    config/db.js
    models/        User.js, Document.js
    middleware/    auth.js, upload.js
    controllers/   authController.js, documentController.js
    routes/        authRoutes.js, documentRoutes.js
    uploads/       (stored files, created automatically)
  client/
    src/
      api.js, App.jsx, main.jsx, index.css
      context/AuthContext.jsx
      components/ProtectedRoute.jsx
      pages/       Login.jsx, Register.jsx, Dashboard.jsx
```

## Prerequisites (Windows)
- Node.js 18+ (https://nodejs.org)
- MongoDB Community Server running locally (or a MongoDB Atlas URI)
- Postman, VS Code

## Setup and Run

### 1. Backend
```
cd server
npm install
copy .env.example .env
```
Edit `.env` and set a strong `JWT_SECRET` (and `MONGO_URI` if not using local MongoDB). Then:
```
npm run dev
```
Server: http://localhost:5000  (health check: http://localhost:5000/api/health)

### 2. Frontend (new terminal)
```
cd client
npm install
copy .env.example .env
npm run dev
```
Open http://localhost:5173

## API Reference

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | /api/auth/register | No | Create account `{name,email,password}` |
| POST | /api/auth/login | No | Login `{email,password}` -> `{token,user}` |
| GET | /api/auth/me | Yes | Current user |
| POST | /api/documents | Yes | Upload (form-data: `file`, `title`, `description`) |
| GET | /api/documents?search=term | Yes | List / search own documents |
| GET | /api/documents/:id | Yes | Document details |
| GET | /api/documents/:id/download | Yes | Download file |
| DELETE | /api/documents/:id | Yes | Delete document and file |

Protected routes need the header: `Authorization: Bearer <token>`

## Postman Testing Steps
1. **Register** - POST `/api/auth/register`, body (raw JSON): `{"name":"Alice","email":"alice@test.com","password":"secret123"}` -> expect `201` with token.
2. **Login** - POST `/api/auth/login` -> copy the `token`. Wrong password -> `401`.
3. In Postman set Authorization -> Bearer Token -> paste token (or use a collection variable `{{token}}`).
4. **Upload** - POST `/api/documents`, Body -> form-data: key `file` (type File), `title` (Text), `description` (Text) -> expect `201`. Copy the returned `_id`.
5. **Validation** - upload an `.exe` or a file over 10 MB -> expect `400`.
6. **List** - GET `/api/documents` -> your documents.
7. **Search** - GET `/api/documents?search=report`.
8. **Download** - GET `/api/documents/:id/download` -> use "Send and Download".
9. **No token** - call any `/api/documents` route without the token -> `401`.
10. **Ownership check** - register a second user (Bob), login, and call GET/download/DELETE on Alice's document id with Bob's token -> expect `404`. Bob's list is empty.
11. **Delete** - DELETE `/api/documents/:id` with Alice's token -> `200`; the file is also removed from `server/uploads`.

## Security Notes
- Passwords hashed with bcrypt; never returned by the API.
- Uploaded files get random stored names; MIME type and extension are both checked.
- Search input is regex-escaped to prevent regex injection.
- Files are served only through authenticated download endpoint (the `uploads` folder is not public).
- For production: use HTTPS, rate-limiting (express-rate-limit), helmet, and cloud storage.
